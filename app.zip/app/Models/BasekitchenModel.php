<?php

namespace App\Models;

use CodeIgniter\Model;

class BasekitchenModel extends Model
{
    protected $table = 'base_kitchen';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'base_kitchen_name',
        'status'
    ];

public function basekitchencreate($data){
    return $this->insert($data);
}

    public function getBasekitchenByName($base_kitchen_name)
    {
        $result =  $this->db->table('base_kitchen b')
            ->select('b.*')
            ->where('b.base_kitchen_name', $base_kitchen_name)
            ->get()
            ->getResultArray();
        // echo $this->db->getLastQuery();
        return $result;
    }

    public function insertBasekitchenIfNotExist($base_kitchen_name)
    {
        $base_kitchen_id = '';
        $base_kitchen_data = $this->getBasekitchenByName($base_kitchen_name);
        if (count($base_kitchen_data) > 0) {
            $base_kitchen_id = $base_kitchen_data[0]['id'];
        } else {
            $base_kitchen_data_insert = array('base_kitchen_name' => $base_kitchen_name);
            $this->insert($base_kitchen_data_insert);
            $base_kitchen_id = $this->getInsertID();
        }
        return $base_kitchen_id;
    }

    public function getdata(){
        return $this->findAll();
    }

    public function basekitchenupdate($id,$data){
        return $this->update($id,$data);
    }

    public function deleterow($id){
        return $this->delete($id);
    }

}
