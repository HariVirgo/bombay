<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table = 'category';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'category_name',
        'status'
    ];


    public function createcategory($data){
        return $this->insert($data);
    }

    public function getCategoryByName($category_name)
    {
        $result =  $this->db->table('category c')
            ->select('c.*')
            ->where('c.category_name', $category_name)
            ->get()
            ->getResultArray();
        // echo $this->db->getLastQuery();
        return $result;
    }

    public function insertCategoryIfNotExist($category_name)
    {
        $category_id = '';
        $category_data = $this->getCategoryByName($category_name);
        if (count($category_data) > 0) {
            $category_id = $category_data[0]['id'];
        } else {
            $category_data_insert = array('category_name' => $category_name);
            $this->insert($category_data_insert);
            $category_id = $this->getInsertID();
        }
        return $category_id;
    }

    public function getdata(){
        return $this->findAll();
    }

    public function categoryupdate($id,$data){
        return $this->update($id,$data);
    }

    
    public function deleterow($id){
        return $this->delete($id);
    }


}
