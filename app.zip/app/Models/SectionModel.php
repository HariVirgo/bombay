<?php

namespace App\Models;

use CodeIgniter\Model;

class SectionModel extends Model
{
    protected $table = 'section';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'section_name',
        'status'
    ];



    public function sectioncreate($data){
        return $this->insert($data);
    }


    public function getdata(){
        return $this->findAll();
    }

    public function sectionupdate($id,$data){
        return $this->update($id,$data);
    }



    public function deleterow($id){
        return $this->delete($id);
    }

    public function getsectionName($s_code){
        $result =  $this->db->table('section s')
        ->select('s.section_name')
        ->where('s.id', $s_code)
        ->get()
        ->getResultArray();
        // print_r($result);
        // die;
    // echo $this->db->getLastQuery();
    return $result;
    }

}