<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'product';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'item_name',
        'category_id',
        'base_unit_id',
        'select_unit',
        'preferred_unit',
        'item_code',
        'gst_code',
        'sac_code',
        'base_kitchen_id',
        'section_id',
        'type_outlet',
        'yield',
        'non_stockable',
        'aliase_name'

    ];


    public function getProductByItemCode($item_code)
    {

        // $this->join('product', 'product.category_id = category.id', 'LEFT');
        // $this->select('product.*');
        // $this->select('category.*');
        // $this->select('Table_3.*');
        // $this->orderBy('product.id');
        // $result = $this->findAll();

        // echo $this->db->getLastQuery();


        $result =  $this->db->table('product p')
            ->join('category c', 'c.id = p.category_id')
            ->select('p.*, c.*')
            ->where('p.item_code', $item_code)
            ->get()
            ->getResultArray();
        // echo $this->db->getLastQuery();
        return $result;
    }




    public function createproducts($data)
    {
        return $this->insert($data);
    }
  
    public function getdata(){
        $result =  $this->db->table('product p')
        ->join('category c', 'c.id = p.category_id')
        ->join('base_unit b','b.id = p.base_unit_id')
        ->join('base_kitchen bk', 'bk.id = p.base_kitchen_id')
        ->join('section s', 's.id = p.section_id','left')
        ->select('p.*,c.category_name,b.base_unit_name,bk.base_kitchen_name,s.section_name')
        ->get()
        ->getResultArray();
        // echo '<pre>';
        // print_r($result);
        // die;
       return $result;
    }

    public function editdata($id){
        return $this->where('id',$id)->first();
    }

    public function productupdate($id,$data){
        return $this->update($id,$data);
    }

    public function deleterow($id){
        return $this->delete($id);
    }

}
