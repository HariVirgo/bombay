<?php

namespace App\Models;

use CodeIgniter\Model;

class BaseunitModel extends Model
{
    protected $table = 'base_unit';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'base_unit_name',
        'status'
    ];


    public function baseunitcreate($data){
        return $this->insert($data);
    }

    public function getBaseunitByName($base_unit_name)
    {
        $result =  $this->db->table('base_unit b')
            ->select('b.*')
            ->where('b.base_unit_name', $base_unit_name)
            ->get()
            ->getResultArray();
        // echo $this->db->getLastQuery();
        return $result;
    }


    public function insertBaseunitIfNotExist($base_unit_name)
    {
        $base_unit_id = '';
        $base_unit_data = $this->getBaseunitByName($base_unit_name);
        if (count($base_unit_data) > 0) {
            $base_unit_id = $base_unit_data[0]['id'];
        } else {
            $base_unit_data_insert = array('base_unit_name' => $base_unit_name);
            $this->insert($base_unit_data_insert);
            $base_unit_id = $this->getInsertID();
        }
        return $base_unit_id;
    }


    public function getdata(){
        return $this->findAll();
    }

    public function baseunitupdate($id,$data){
        return $this->update($id,$data);
    }

    public function deleterow($id){
        return $this->delete($id);
    }

}
