<?php

namespace App\Models;

use CodeIgniter\Model;

class LocationModel extends Model
{
    protected $table = 'location';
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'location_name',
        'status'
    ];

    public function locationcreate($data){
        return $this->insert($data);
    }

    public function getdata(){
        return $this->findAll();
    }
    
    public function locationupdate($id, $data){
        return $this->update($id,$data);
    }

    public function deleterow($id){
        return $this->delete($id);
    }
}