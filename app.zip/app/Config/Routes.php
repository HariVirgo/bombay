<?php

namespace Config;

use App\Controllers\ProductsController;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('AuthController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'AuthController::index');
$routes->get('/auth/login', 'AuthController::index');
$routes->get("dashboard", "DashboardController::index");

$routes->get("users", "UserController::index");

// $routes->group('workorder', static function ($routes) {
//     $routes->get("/", "DashboardController::workorder");
//     $routes->get("workordercreate", "DashboardController::workorderform");
// });
$routes->get("semiprocessed", "DashboardController::semiprocessed");
$routes->get("dispatch", "DashboardController::dispatch");

$routes->get("barcode", "DashboardController::barcode");


$routes->get("baseunit", "BaseunitController::index");
$routes->post("baseunitform", "BaseunitController::baseunitform");
$routes->post("updatepost", "BaseunitController::updatepost");
$routes->post("deleterow", "BaseunitController::deleterow");

$routes->post("basekitchenform", "BasekitchenController::basekitchenform");
$routes->get("basekitchen", "BasekitchenController::index");
// $routes->get("basekitchen/show", "BasekitchenController::show");
$routes->post("updatepost", "BasekitchenController::updatepost");
$routes->post("basekitchendelete", "BasekitchenController::basekitchendelete");

$routes->get("section", "SectionController::index");
$routes->post("sectionform","SectionController::sectionform");
$routes->post("sectionupdate","SectionController::sectionupdate");
$routes->post("sectiondelete","SectionController::sectiondelete");



$routes->get("category", "CategoryController::index");
$routes->post("categoryform", "CategoryController::categoryform");
$routes->post("updatecategory", "CategoryController::updatecategory");
$routes->post("categorydelete", "CategoryController::categorydelete");

$routes->get("products", "ProductsController::products");
$routes->post("create", "ProductsController::create");
$routes->post("upload", "ProductsController::upload");
$routes->get("productsform", "ProductsController::productsform");
$routes->get("productseditform/(:num)", "ProductsController::productEditById/$1");
$routes->post("updateproducts", "ProductsController::updateproducts");
$routes->post("productsdelete", "ProductsController::productsdelete");
// $routes->get("productseditform", "ProductsController::productEditById");



$routes->get("location", "LocationController::index");
$routes->post("locationcreate", "LocationController::locationcreate");
$routes->post("updatelocation", "LocationController::updatelocation");
$routes->post("deletelocation", "LocationController::deletelocation");


$routes->post("/auth/login/submit", "UserController::loginAuth");

$routes->get("products/(:num)", "DashboardController::getProductsByCode/$1");
$routes->get("barcode/(:num)", "DashboardController::getbarcode/$1");
$routes->get("section_name/(:num)","SectionController::getSectionbycode/$1");

// $routes->post("barcodezend", "BarcodeController::set_barcode");



/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
