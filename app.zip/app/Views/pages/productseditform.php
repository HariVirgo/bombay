 <?php 
// print_r($products);
// die;
?>
<div class="content-wrapper">
    <div class="page-wrapper">
        <div class="content">
            <div class="card">
                <form action="<?php echo base_url() . '/updateproducts' ?>" method="post" id="editproducts">
                    <div class="card-body">
                        <div class="row">

                            <input type="hidden" name="id" value="<?php echo $products['id'] ?>">


                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Name</label>
                                    <input type="text" id="iname" name="iname" value="<?php echo $products['item_name'] ?>">
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Category</label><br>
                                    <select class="form-select" name="category" id="category">
                                        <?php
                                        if (!empty($category)) {
                                            foreach ($category as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>" <?php
                                                                                    if (!empty($products)) {
                                                                                        echo $k['id'] == $products['category_id'] ? 'selected' : '';
                                                                                        }
                                                                                     ?> >
                                                    <?php echo $k['category_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>

                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Base Unit</label><br>
                                    <select class="form-select" name="baseunit" id="baseunit">
                                        <?php
                                        if (!empty($base_unit)) {
                                            foreach ($base_unit as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>" <?php
                                                                                    if (!empty($products)) {
                                                                                        echo $k['id'] == $products['base_unit_id'] ? 'selected' : '';
                                                                                        }
                                                                                     ?> >
                                                    <?php echo $k['base_unit_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Select Units</label>
                                    <input type="text" id="selectunit" name="selectunit" value="<?php echo $products['select_unit'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Preferred Unit</label>
                                    <input type="text" id="preferredunit" name="preferredunit" value="<?php echo $products['preferred_unit'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Code</label>
                                    <input type="number" id="itemcode" name="itemcode" value="<?php echo $products['item_code'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>GST Code</label>
                                    <input type="text" id="gstcode" name="gstcode" value="<?php echo $products['gst_code'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>HSN/SAC Code Type</label>
                                    <input type="text" id="saccode" name="saccode" value="<?php echo $products['sac_code'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Type For Base Kitchen</label>
                                    <select class="form-select" name="basekitchen" id="basekitchen">
                                        <?php
                                        if (!empty($base_kitchen_name)) {
                                            foreach ($base_kitchen_name as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>" <?php
                                                                                    if (!empty($products)) {
                                                                                        echo $k['id'] == $products['base_kitchen_id'] ? 'selected' : '';
                                                                                        }
                                                                                     ?> >
                                                    <?php echo $k['base_kitchen_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Section</label>
                                    <select class="form-select" name="section" id="section">
                                        <?php
                                        if (!empty($section)) {
                                            foreach ($section as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>" <?php
                                                                                    if (!empty($products)) {
                                                                                        echo $k['id'] == $products['section_id'] ? 'selected' : '';
                                                                                        }
                                                                                     ?> >
                                                    <?php echo $k['section_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Type For Outlet</label>
                                    <input type="text" id="outlet" name="outlet" value="<?php echo $products['type_outlet'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Yield</label><br>
                                    <input type="text" id="yield" name="yield" value="<?php echo $products['yield'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Non Stockable</label>
                                    <input type="text" id="stockable" name="stockable" value="<?php echo $products['non_stockable'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Alias Name</label>
                                    <input type="text" id="aliasname" name="aliasname" value="<?php echo $products['aliase_name'] ?>">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <button type="submit" class="btn btn-primary">Save changes</button>
                                <a href="<?php echo base_url() . '/products' ?>" class="btn btn-warning">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

