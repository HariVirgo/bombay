<?php
// print_r($location);
// die;
?>
<!-- Content Wrapper. Contains page content -->
<!-- <script src="https://code.jquery.com/jquery-3.2.0.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.2/xlsx.full.min.js"></script>
<script src="<?php echo base_url(); ?>/public/plugins/jsondata_exportexcel/excelexportjs.js"></script>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- /.content-header -->

    <!-- Main content -->

    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
        <div class="container-fluid py-1 px-3">
            <nav aria-label="breadcrumb">

                <h2 class="font-weight-bolder mb-0">Semi Processed</h>
            </nav>

        </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-4">
        <div class="card-body">
            <form role="form" class="text-start">
                <!-- <div class="input-group input-group-outline my-3">
                    <label class="form-label"></label>
                    <select id="selectedBranch" class="form-control" ng-model="selectedBranch" ng-options="x for x in branch">
                        <?php
                        if (!empty($location)) {
                            foreach ($location as $k) {
                        ?>

                                <option value="<?= $k['location_name'] ?>">
                                    <?php echo $k['location_name']; ?>
                                </option>
                        <?php
                            }
                        }
                        ?>
                </div> -->
                <div class="input-group input-group-outline mb-3">
                    <!-- <label class="form-label">Product Code</label> -->
                    <input type="text" class="form-control input-item" name="pcode" id="pcode" ng-model="pcode" autofocus="autofocus" ng-change="getdata(pcode)" placeholder="Product Code">
                </div>
            </form>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card my-4">

                    <div class="card-body px-0 pb-2">
                        <div class="table-responsive p-0">
                            <!-- <div class="col-md-3"> -->
                            <div class="col-md-12">

                                <button type="button" class="btn bg-pink w-100 my-4 mb-2" id="excelExport">Export</button>
                            </div>
                            <div id="dvjson"></div>


                            <table class="table align-items-center mb-0" id="export">

                                <thead>
                                    <tr>
                                        <td>Category Name</td>
                                        <td>Item Code</td>
                                        <td>Item Name</td>
                                        <td>Unit</td>
                                        <td>Quantity</td>
                                        <td>Comment</td>
                                        <td>Expiry Type</td>
                                        <td>Expiry Date</td>
                                        <td style="display:none;">section ID</td>

                                    </tr>
                                </thead>

                                <tbody id="semi">



                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {


        $('#excelExport').click(async function() {
            var table = document.getElementById("export");
            var header = [];
            var rows = [];
            for (var i = 0; i < table.rows[0].cells.length; i++) {
                header.push(table.rows[0].cells[i].innerHTML);
            }
            for (var i = 1; i < table.rows.length; i++) {
                var row = {};
                for (var j = 0; j < table.rows[i].cells.length; j++) {
                    row[header[j]] = table.rows[i].cells[j].innerHTML;
                }
                rows.push(row);
                console.log(rows);
            }
            // console.log(rows);
            var selected_section = [];
            for (var i = 0; i < rows.length; i++) {
                // console.log(rows[i]["section ID"]);
                if (!selected_section.includes(rows[i]["section ID"])) {
                    selected_section.push(rows[i]["section ID"])
                }
            }
            // console.log(selected_section);
            for (var i = 0; i < selected_section.length; i++) {
                var filter = rows.filter(function(el) {
                    var isSameSection = el["section ID"] == selected_section[i];
                    isSameSection ? delete el["section ID"] : '';
                    return isSameSection;
                });
                console.log(filter);
                await $.ajax({
                    url: '<?= base_url('section_name/') ?>/' + selected_section[i],
                    type: 'GET',
                    success: function(response) {
                        // console.log(response);
                        response = JSON.parse(response);
                        var currentDate = new Date().toJSON().slice(0, 10);
                        var section_name = response[0]['section_name']
                        var file_name = section_name + '-' + currentDate;
                        var josnData = JSON.stringify(filter);
                        var jsonDataObject = eval(josnData);
                        // exportWorksheet(jsonDataObject, file_name);
                        // console.log(jsonDataObject);
                        var headers = {
                            category: 'Category Name'.replace(/,/g, ''), // remove commas to avoid errors
                            item_code: "Item Code",
                            item_name: "Item Name",
                            unit: "Unit",
                            quantity: "Quantity",
                            comment: "Comment",
                            type: "Expiry Type",
                            date: "Expiry Date"
                        };
                        exportCSVFile(headers, jsonDataObject, file_name)
                    }
                });


            }











            // var selectedBranch = $("#selectedBranch").val();
            // var currentDate = new Date().toJSON().slice(0, 10);

            // var filename = currentDate + "-" + selectedBranch;
            // console.log(filename);

            // $("#export").table2excel({
            //     exclude: ".excludeThisClass",
            //     name: "Worksheet Name",
            //     filename: filename + ".xls", // do include extension
            //     preserveColors: false // set to true if you want background colors and font colors preserved
            // });

        })


        // $(document).on('change', '.edit_btn', function() {

        $('#pcode').on("keypress", function(e) {
            if (e.keyCode == 13) {
                e.preventDefault(0);
                var product_code = $(this).val();
                if (product_code.length < 9) {
                    return false;
                }

                console.log('change', product_code);

                $.ajax({
                    url: '<?= base_url('products/') ?>/' + product_code,
                    type: 'GET',
                    success: function(response) {
                        console.log(response);

                        if (response['status'] == 200) {
                            var products = response['data'];
                            initProducts(products, product_code);
                        }

                        if (response['status'] == 400) {
                            productNotFound();
                        }

                        $("#pcode").val('');



                    }
                });
            }

        });



        function initProducts(data, product_code) {
            var code = product_code.split("").reverse().join("");
            var reverse = code.split('000')
            //   var qty = product_code.split('000')
            var qty = reverse[0].split("").reverse().join("");

            var productHtml = '';
            data.forEach(element => {

                productHtml += '<tr> <td>' + element['category_name'] + '</td>';
                productHtml += '<td>' + element['item_code'] + '</td>';
                productHtml += '<td>' + element['item_name'] + '</td>';
                productHtml += '<td>' + element['select_unit'] + '</td>';
                productHtml += '<td>' + qty + '</td>';
                productHtml += '<td></td>';
                productHtml += '<td></td>';
                productHtml += '<td></td>';
                productHtml += '<td style="display:none;">' + element['section_id'] + '</td> </tr>';


            });

            $('#semi').append(productHtml);
        }

        function productNotFound() {
            var productHtml = '<tr><td colspan="6" style="text-align:center;"> Product not found </td></tr>';
            $('#semi').after(productHtml);
        }


    });
</script>