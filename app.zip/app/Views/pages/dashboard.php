
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                   
                     <!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

                <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
                    <div class="container-fluid py-1 px-3">
                        <nav aria-label="breadcrumb">

                            <h2 class="font-weight-bolder mb-0">Dashboard</h>
                        </nav>

                    </div>
                </nav>
                <div class="row">
                    <div class="col-md-6 col-6">
                        <a href="<?php echo base_url().'/semiprocessed' ?>">
                            <div class="card">
                                <div class="card-header mx-4 p-3 text-center">
                                    <div class="icon icon-shape icon-lg bg-pink shadow text-center border-radius-lg">
                                        <i class="fas fa-hamburger"></i>
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Semi Processed</h6>

                                </div>
                            </div>
                        </a>

                    </div>
                    <div class="col-md-6 col-6">
                        <a href="<?php echo base_url().'/dispatch' ?>">
                            <div class="card">
                                <div class="card-header mx-4 p-3 text-center">

                                    <div class="icon icon-shape icon-lg bg-pink shadow text-center border-radius-lg">
                                        <i class="fas fa-box"></i>
                                    </div>
                                </div>
                                <div class="card-body pt-0 p-3 text-center">
                                    <h6 class="text-center mb-0">Dispatch</h6>

                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->