<?php
$timer = timer();

?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>

<div class="content-wrapper">

               
                <?php if(session()->getFlashdata('error')):?>
                    <div class="col-12">
                    <div class="alert alert-warning">
                       <?= session()->getFlashdata('error') ?>
                    </div>
                    </div>
                <?php endif;?>

                <?php if(session()->getFlashdata('success')):?>
                    <div class="col-12">
                    <div class="alert alert-success">
                       <?= session()->getFlashdata('success') ?>
                    </div>
                    </div>
                <?php endif;?>

    <div class="content">
        <!-- <div class="page-header"> -->
        <div class="row">
            <div class="col-md-10">
            <!-- <div class="importsuccess alert alert-success">Successfully</div>
                    <div class="importfaild alert alert-danger">Faild</div> -->
                <br>
                <form action="<?php echo base_url() . '/upload' ?>" method="post" enctype="multipart/form-data">
                    <input type="file" class="btn btn-primary" id="file" name="file" required>
                    <button type="submit" class="btn btn-primary" name="submit">IMPORT</button>   
                </form>
            </div>
            <div class="col-md-2">
                <br>
                <a href="<?php echo base_url() . '/productsform' ?>"><button type="button" class="btn btn-primary float-right">Add</button></a>

            </div>
        </div>

        <!-- </div> -->
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <button type="button" class="btn btn-info" id="excelexport" name="excelexport">Export</button>
                <table class="table table-striped table-bordered" id="example" name="example">
                    <thead>
                        <tr>
                            <th style="text-align: center;">ID</th>
                            <th style="text-align: center;">Item Name</th>
                            <th style="text-align: center;">Category</th>
                            <th style="text-align: center;">Base Unit</th>
                            <th style="text-align: center;">Select Units</th>
                            <th style="text-align: center;">Preferred Unit</th>
                            <th style="text-align: center;">Item Code</th>
                            <th style="text-align: center;">GST Code</th>
                            <th style="text-align: center;">HSN/SAC Code Type</th>
                            <th style="text-align: center;">Item Type For Base Kitchen</th>
                            <th style="text-align: center;">Section</th>
                            <th style="text-align: center;">Item Type For Outlet</th>
                            <th style="text-align: center;">Yield</th>
                            <th style="text-align: center;">Non Stockable</th>
                            <th style="text-align: center;">Alias Name</th>
                            <th style="text-align: center;">Action</th>
                            <th style="text-align: center;">ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productstable as $k) : ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $k['id'] ?></td>
                                <td style="text-align: center;"><?php echo $k['item_name'] ?></td>
                                <td style="text-align: center;"><?php echo $k['category_name'] ?></td>
                                <td style="text-align: center;"><?php echo $k['base_unit_name'] ?></td>
                                <td style="text-align: center;"><?php echo $k['select_unit'] ?></td>
                                <td style="text-align: center;"><?php echo $k['preferred_unit'] ?></td>
                                <td style="text-align: center;"><?php echo $k['item_code'] ?></td>
                                <td style="text-align: center;"><?php echo $k['gst_code'] ?></td>
                                <td style="text-align: center;"><?php echo $k['sac_code'] ?></td>
                                <td style="text-align: center;"><?php echo $k['base_kitchen_name'] ?></td>
                                <td style="text-align: center;"><?php echo $k['section_name'] ?></td>
                                <td style="text-align: center;"><?php echo $k['type_outlet'] ?></td>
                                <td style="text-align: center;"><?php echo $k['yield'] ?></td>
                                <td style="text-align: center;"><?php echo $k['non_stockable'] ?></td>
                                <td style="text-align: center;"><?php echo $k['aliase_name'] ?></td>
                                <td style="text-align: center;">
                                    <a href="<?php echo base_url() .'/productseditform/'.$k['id'] ?>" class="btn btn-info btn-sm">edit</a>
                                    <button class="btn btn-danger btn-sm" data-target="#deleteModal<?php echo $k['id']; ?>" data-toggle="modal">Delete</button>
                                </td>
                                <td style="text-align: center;"><?php echo $k['id'] ?></td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

    <?php foreach ($productstable as $k) :  ?>
        <div class="modal fade" tabindex="-1" role="dialog" id="deleteModal<?php echo $k['id']; ?>">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <!-- <h4 class="modal-title">Add Category</h4> -->
                    </div>

                    <form role="form" action="<?php echo base_url() . '/productsdelete' ?>" method="post" id="deleteForm">

                        <input type="hidden" name="id" value="<?php echo $k['id']; ?>">
                        <div class="modal-body">
                            <p>Do you really want to remove?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>

                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php endforeach ?>

</div>
<script>
    var ajax_table = $('#example').DataTable();

    $(document).ready(function() {
       

        $('#excelexport').click(function() {

            $("#example").table2excel({
                exclude: ".excludeThisClass",
                name: "Worksheet Name",
                filename: "SomeFile.xls", // do include extension
                preserveColors: false // set to true if you want background colors and font colors preserved
            });

        });

        $('.alert').delay(3000).fadeOut(300);


    });
</script>