<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- /.content-header -->

    <!-- Main content -->

    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
            <div class="container-fluid py-1 px-3">
                <nav aria-label="breadcrumb">

                    <h2 class="font-weight-bolder mb-0">Distpatch</h>
                </nav>

            </div>
        </nav>
        <!-- End Navbar -->
        <div class="container-fluid py-4">
            <div class="card-body">
                <!-- <form role="form" class="text-start"> -->
                    <div class="input-group input-group-outline my-3">
                        <label class="form-label"></label>
                        <select id="selectedBranch" class="form-control" ng-model="selectedBranch" ng-options="x for x in branch">
                        <?php
                                        if (!empty($location)) {
                                            foreach ($location as $k) {
                                        ?>

                                                <option value="<?= $k['location_name'] ?>">
                                                    <?php echo $k['location_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                    </div>
                    <div class="input-group input-group-outline mb-3">
                        <label class="form-label">Product Code</label>
                        <input type="text" class="form-control" name="pcode" id="pcode" ng-model="pcode" autofocus="autofocus">
                    </div>



                <!-- </form> -->
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card my-4">

                        <div class="card-body px-0 pb-2">
                            <div class="table-responsive p-0">

                                <button type="button" name="excel" id="excelExport" class="btn bg-pink w-100 my-4 mb-2">Export</button>

                                <table id="export" name="export" class="table align-items-center mb-0">

                                    <thead>
                                        <tr>
                                            <td>Category Name</td>
                                            <td>Item Name</td>
                                            <td>Unit</td>
                                            <td>Quantity</td>
                                            <td>Unit Price</td>
                                            <td>Comment</td>

                                        </tr>
                                    </thead>
                                    <tbody id=dispatch>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>




<script>
    $(document).ready(function() {

        $('#excelExport').click(function() {
            var selectedBranch = $("#selectedBranch").val();
            var currentDate = new Date().toJSON().slice(0,10);

            var filename = currentDate + "-" + selectedBranch;
            console.log( filename);

            $("#export").table2excel({
                exclude: ".excludeThisClass",
                name: "Worksheet Name",
                filename: filename + ".xls", // do include extension
                preserveColors: false // set to true if you want background colors and font colors preserved
            });

        })


        // $(document).on('change', '.edit_btn', function() {
        //             $('#myText').on("keypress", function(e) {
        //         if (e.keyCode == 13) {
        //             alert("Enter pressed");
        //             return false; // prevent the button click from happening
        //         }
        // });
        $('#pcode').on("keypress", function(e) {
            if (e.keyCode == 13) {
                var product_code = $(this).val();
                if (product_code.length < 9) {
                    return false;
                }

                console.log('change', product_code);

                $.ajax({
                    url: '<?= base_url('products/') ?>/' + product_code,
                    type: 'GET',
                    success: function(response) {
                        console.log(response);

                        if (response['status'] == 200) {
                            var products = response['data'];
                            initProducts(products, product_code);
                        }

                        if (response['status'] == 400) {
                            productNotFound();
                        }

                        $("#pcode").val('');



                    }
                });
            }

        });



        function initProducts(data, product_code) {
        //    var code = product_code.reverse();
          var code = product_code.split("").reverse().join("");
          var reverse = code.split('000')
        //   var qty = product_code.split('000')
         var qty = reverse[0].split("").reverse().join("");
           
          
            var productHtml = '';
            data.forEach(element => {
                productHtml += '<tr> <td>' + element['category_name'] + '</td>';
                productHtml += '<td>' + element['item_name'] + '</td>';
                productHtml += '<td>' + element['select_unit'] + '</td>';
                productHtml += '<td>' + qty + '</td>';
                productHtml += '<td></td>';
                productHtml += '<td></td> </tr>';
            });

            $('#dispatch').append(productHtml);
        }

        function productNotFound() {
            var productHtml = '<tr><td colspan="6" style="text-align:center;"> Product not found </td></tr>';
            $('#dispatch').html(productHtml);
        }



    });
</script>