<?php
// echo '<prev>';
// print_r($edit);
// die;
?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>

<div class="content-wrapper">

<?php if(session()->getFlashdata('error')):?>
                    <div class="col-12">
                    <div class="alert alert-warning">
                       <?= session()->getFlashdata('error') ?>
                    </div>
                    </div>
                <?php endif;?>

                <?php if(session()->getFlashdata('success')):?>
                    <div class="col-12">
                    <div class="alert alert-success">
                       <?= session()->getFlashdata('success') ?>
                    </div>
                    </div>
                <?php endif;?>

    <div class="content">
        <!-- <div class="page-header"> -->

        <div class="row">
            <div class="col-md-10">
                <div class="alert alert-success" id="success" style="display:none;" role="alert">
                    This is a success alert—check it out!
                </div>
                <div class="alert alert-danger" id="failed"  style="display:none;" role="alert">
                    This is a danger alert—check it out!
                </div>
            </div>
            <div class="col-md-2">
                <br>
                <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#addModal"> Add </button>

            </div>
        </div>
    </div>


    <div class="modal fade" tabindex="-1" role="dialog" id="addModal">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <!-- <h4 class="modal-title">Add Category</h4> -->
                </div>

                <form role="form" action="<?php echo base_url() . '/sectionform' ?>" method="post" id="createForm">

                    <div class="modal-body">

                        <div class="form-group">
                            <label for="section">Section</label>
                            <input type="text" class="form-control" id="section" name="section" placeholder="Enter section name" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="active">Status</label>
                            <select class="form-control" id="active" name="active">
                                <option value="1">Active</option>
                                <option value="2">Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                </form>


            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="manageTable" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Base Kitchen</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                   
                        <tbody>
                        <?php foreach ($section as $k) : ?>
                            <tr>
                                <td><?php echo $k['id'] ?></td>
                                <td><?php echo $k['section_name'] ?></td>
                                <td><?php if ($k['status'] == '1') {
                                        echo 'Active';
                                    } else {
                                        echo 'Inactive';
                                    } ?></td>
                                <td>
                                    <button class="btn btn-info btn-sm" data-target="#editModal<?php echo $k['id']; ?>" data-toggle="modal">edit</button>
                                    <button class="btn btn-danger btn-sm" data-target="#deleteModal<?php echo $k['id']; ?>" data-toggle="modal">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php foreach ($section as $k) : ?>
        <div class="modal fade" tabindex="-1" role="dialog" id="editModal<?php echo $k['id']; ?>">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <!-- <h4 class="modal-title">Add Category</h4> -->
                    </div>

                    <form role="form" action="<?php echo base_url() . '/sectionupdate' ?>" method="post" id="editForm">

                        <div class="modal-body">
                            <input type="hidden" name="id" value="<?php echo $k['id'] ?>">
                            <div class="form-group">
                                <label for="base_unit">Section</label>
                                <input type="text" class="form-control" id="section" name="section" value="<?php echo $k['section_name'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="active">Status</label>
                                <select class="form-control" id="active" name="active">
                                    <option value="1" <?php if ($k['status'] == '1') {
                                                            echo 'Selected';
                                                        }  ?>>Active</option>
                                    <option value="2" <?php if ($k['status'] == '2') {
                                                            echo 'Selected';
                                                        }  ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>

                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php endforeach ?>

    <?php foreach ($section as $k) :  ?>
        <div class="modal fade" tabindex="-1" role="dialog" id="deleteModal<?php echo $k['id']; ?>">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <!-- <h4 class="modal-title">Add Category</h4> -->
                    </div>

                    <form role="form" action="<?php echo base_url() . '/sectiondelete' ?>" method="post" id="deleteForm">

                        <input type="hidden" name="id" value="<?php echo $k['id']; ?>">
                        <div class="modal-body">
                            <p>Do you really want to remove?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>

                    </form>


                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
    <?php endforeach ?>

</div>

</div>

<script>
   var ajax_table = $('#manageTable').DataTable();
   $(document).ready(function() {
    $('.alert').delay(3000).fadeOut(300);
  });
</script>