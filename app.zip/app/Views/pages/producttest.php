<?php 
// echo "<pre>";
// print_r($category);

    // foreach ($category as $k => $val):
        // echo $k. "<br>";
        // echo $val['id'];
        // echo $val['category_name'];
        // echo $k . "  " .$val ."<br>";
        // echo $products
    // endforeach;

    // die;
?>
<div class="content-wrapper">
<div class="page-wrapper">
            <div class="content">
                <div class="card">
              
                </div>

            </div>
        </div>


</div>