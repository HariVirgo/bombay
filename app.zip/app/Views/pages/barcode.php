<!-- <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/barcodes/JsBarcode.code39.min.js"></script> -->
<!-- <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.8.0/dist/JsBarcode.all.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/thermal-printer@0.2.2/dist/ThermalPrinter.min.js"></script> -->
<!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia"> -->
<link href="https://fonts.cdnfonts.com/css/arial" rel="stylesheet">



<style>
  @media print {

    html,
    body {
      font-family: 'Times New Roman', Times, serif;
      width: 30px;

      height: 384px;

    }
  }

  #barcodeTarget {
    /* width: 192px !important; */
    display: none;


  }
</style>
<?php
// $date = date('d-m-y h:i:s');
// echo $date;
?>

<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- /.content-header -->

    <!-- Main content -->

    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">

          <h2 class="font-weight-bolder mb-0">Semi Processed</h>
        </nav>

      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-4">
      <div class="card-body" id="thermalprint">
        <style>


        </style>
        <img id="barcode" />
        <form role="form" class="text-start">
          <div class="input-group input-group-outline mb-3">
            <label class="form-label">Product Code</label>
            <input type="text" class="form-control" name="pcode" id="pcode" ng-model="pcode" autofocus="autofocus" required>
          </div>

          <div>

            <div class="input-group input-group-outline mb-3">


              <input type="text" class="form-control" name="pname" id="pname" placeholder="Product Name">
            </div>
            <div class="input-group input-group-outline mb-3">


              <input type="text" class="form-control" name="weight" id="weight" placeholder="Weight">
            </div>
            <div class="input-group input-group-outline mb-3">


              <input type="text" class="form-control" name="price" id="price" placeholder="Price">
            </div>
            <div class="input-group input-group-outline mb-3">


              <input type="date" class="form-control" name="tdate" id="tdate" placeholder="<?php echo date('d-m-y h:i:s');
                                                                                            ?>">
            </div>
            <div class="input-group input-group-outline mb-3">


              <input type="text" class="form-control" name="bestbefore" id="bestbefore" placeholder="Best Before">
            </div>
            <div class="input-group input-group-outline mb-3">

              <input type="text" class="form-control" name="nop" id="nop" placeholder="Number of print" value="2">
            </div>

          </div>

          <div class="input-group input-group-outline mb-3">
            <button class="btn btn-warning" id="print" type="button">Print</button>
          </div>





        </form>


        <div id="barcodeTarget" class="barcodeTarget" style="height: 54px; width: 111px;">Barcode</div>
        <!-- <div id="barcodeTargetContainer">
          <img id="barcodeTarget" class="barcodeTarget"  /> -->
        <!-- style="height: 54px; width: 111px;" -->
        <!-- </div> -->

        <!-- <div class="row" ng-bind-html="htmlstring"></div> -->
      </div>
    </div>
  </div>
  <!-- <script src="public/assets/js/printthis.js"></script> -->
  <script>
    $(document).ready(function() {



      // $(document).on('change', '.edit_btn', function() {
      // $('#tdate').datepicker('setDate', 'today');
      // $('#tdate').datepicker().datepicker('setDate', 'today');
      // $('#tdate').datepicker({
      // "setDate": new Date(),
      // "autoclose": true
      //    });


      $('#pcode').on("keypress", function(e) {
        if (e.keyCode == 13) {
          e.preventDefault(0);
          var product_code = $(this).val();

          // if (product_code.length < 9) {
          //   return false;
          // }

          console.log('change', product_code);
          // var nop = $('#nop').val();
          // if((nop%2) != "0"){
          //   $('#print').prop('disabled',true);
          // }
          $.ajax({
            url: '<?= base_url('barcode/') ?>/' + product_code,
            type: 'GET',
            success: function(response) {
              console.log(response);

              if (response['status'] == 200) {
                var products = response['data'];
                initProducts(products);
              }

              if (response['status'] == 400) {
                productNotFound();
              }

              // $("#pcode").val('');



            }
          });
        }

      });

      $('#nop').change(function() {
        //alert();
        var nop = $('#nop').val();
        //alert(nop%2);
        if ((nop % 2) != "0") {
          // alert("log");
          $('#print').prop('disabled', true);
        } else {
          $('#print').prop('disabled', false);

        }
      });

      function initProducts(data) {
        console.log(data[0]);
        $('#pname').val(data[0].item_name);
        $('#weight').val(data[0].weight);
        $('#price').val(data[0].price);
        $('#tdate').val(data[0].date);
        // $('#bestbefore').val(data[0].base_unit_id);

      }

      $('#print').on('click', function() {
        console.log('print this')
        printThis();
      })
      function printThis() {

        var pcode = $('#pcode').val();
        var pname = $('#pname').val();
        var weight = $('#weight').val();
        var price = $('#price').val();
        var tdate = $('#tdate').val();
        var bestbefore = $('#bestbefore').val();
        var nop = $('#nop').val();

        var printElements = `
          <div class="printTicket">
          <div class="row" style="width:384px; margin-top:1px;  margin-left:1px; margin-right:1px; padding:2px; ">`;
        // font-family: auto;
        var barcode = pcode + `000` + weight;
        console.log(barcode);
        generateBarcode(barcode);
        //  JsBarcode("#barcodeTarget", barcode);
        // JsBarcode("#barcodeTarget", barcode, {

        //   width: 2,
        //   height: 100,
        //   displayValue: true
        // });


        var barcodeImg = $('#barcodeTarget').html();
        console.log(barcodeImg);
        for (var i = 0; i < nop; i++) {
          // htmlstring = htmlstring +'<div class="col-6"><div class="ticket"><div class="col-md-6" style="text-align: center;"><span style="font-size:14px;font-weight:800;">BOMBAY SWEETS</span><br><span style="font-size:12px;font-weight:800;">'+pname+'</span><br><br><span style="font-size:10px;">'+barcode+'</span><br><br><span style="font-size:10px;float:left;">WT:'+weight+'Nos</span><span style="font-size:10px;float:right;font-weight:800;"> MRP:Rs.'+price+'</span><br><span style="font-size:8px;float:left;">PKD:'+tdate+'</span> <span style="font-size:8px;float:right;"> Before '+bestbefore+' Days</span></div></div></div><br>';


          // printElements += '<div class="row" style="width:50%;"><div class="col-md-6" style="text-align: center;width:96%;"><div style="font-size:10px;font-weight:800;">BOMBAY SWEETS</div><div style="font-size:9px;font-weight:800;">' + pname + '</div><span>' + barcodeImg + '</span><br><div style="font-size:8px; float:left; font-weight:800;">WT:' + weight + 'Nos</div><div style="font-size:8px; float:right; font-weight:800;"> MRP:Rs.' + price + '</div><div style="font-size:8px; float:left; font-weight:800;">PKD:' + tdate + '</div><div style="font-size:8px; float:right; font-weight:800;"> Before ' + bestbefore + ' Days</div></div></div><br><br><br><br><br><br>';
          // final code-------------------------
          // printElements += '  <div class="row" style="width:50%;"><div class="col-md-6" style="text-align: center;width:96%; height: 123px;"><div style="font-size:10px;font-weight:800;">BOMBAY SWEETS</div><div style="font-size:9px;font-weight:800;">' + pname + '</div><span>' + barcodeImg + '</span><br><div><span style="font-size:8px; float:left; font-weight:800;">WT:' + weight + 'Nos</span><span style="font-size:8px; float:right; font-weight:800;"> MRP:Rs.' + price + '</span></div><div><span style="font-size:9px; float:left; font-weight:800;">PKD:' + tdate + '</span><span style="font-size:8px; float:right; font-weight:800;"> Before ' + bestbefore + ' Days</span></div></div></div><br><br><br><br><br>';
          printElements += '<div class="row" style="width:50%;"><div class="col-md-6" style="text-align: center;width:96%; height: 123px;line-height: 16px;"><div style="font-size:16px;font-weight:600;">BOMBAY SWEETS</div><div style="font-size:14px;font-weight:500;">' + pname + '</div><span >' + barcodeImg + '</span><br><div><span style="font-size:12px; float:left; font-weight:600;">WT:' + weight + 'Nos</span><span style="font-size:14; float:right; font-weight:600;"> MRP:Rs.' + price + '</span></div><div><span style="font-size:12px; float:left; font-weight:600;">PKD:' + tdate + '</span><span style="font-size:10px; float:right; font-weight:600;"> Before ' + bestbefore + ' Days</span></div></div></div><br><br><br><br><br>';

        }
        printElements += `</div></div>`
        printWithCss(printElements);
        console.log('1234567', printElements);
      }


      function printWithCss(printElements) {
        var title = document.title;
        var printWindow = window.open("", "_blank", "");
        printWindow.document.open();
        printWindow.document.write(`<html><head><title>` + title + `</title>
        <link rel="stylesheet" type="text/css" href="public/assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="public/assets/css/thermalprint.css"></head><body>`);
        printWindow.document.write(printElements);
        printWindow.document.write('</body></html>');
        // printWindow.document.close();
        printWindow.focus();
        setTimeout(function() {
          printWindow.print();
          // printWindow.close();
        }, 100);
      }


      function generateBarcode(value) {
        console.log("generate barcode");
        var btype = "code39";
        var settings = {
          output: "svg",
          bgColor: "#FFFFFF",
          color: "#000000",
          // barWidth: 1,
          barHeight: 40,
          moduleSize: 50,
          // 5
          posX: 50,
          // 10
          posY: 25,
          //  20
          addQuietZone: 1
        };
        $("#barcodeTarget").html("").barcode(value, btype, settings);
      }


    });
  </script>






  <!-- <div class="row" style="width:50%;"><div class="col-md-6" style="text-align: center;width:96%;"><div style="font-size:10px;font-weight:800;">BOMBAY SWEETS</div><div style="font-size:9px;font-weight:800;">' + pname + '</div><span>' + barcodeImg + '</span><br><div><span style="font-size:8px; float:left; font-weight:800;">WT:' + weight + 'Nos</span><span style="font-size:8px; float:right; font-weight:800;"> MRP:Rs.' + price + '</span></div><div><span style="font-size:8px; float:left; font-weight:800;">PKD:' + tdate + '</span><span style="font-size:8px; float:right; font-weight:800;"> Before ' + bestbefore + ' Days</span></div></div></div><br><br><br><br><br><br> -->