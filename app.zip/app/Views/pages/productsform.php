<?php
// print_r($section);
// die;
?>
<div class="content-wrapper">
    <div class="page-wrapper">
        <div class="content">
            <div class="card">
                <form action="<?php echo base_url() . '/create' ?>" method="post" id="createproducts">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Name</label>
                                    <input type="text" id="iname" name="iname">
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Category</label><br>
                                    <select class="form-select" name="category" id="category">
                                    <?php
                                    if (!empty($category)) {
                                        foreach ($category as $k) {
                                    ?>

                                                                <option value="<?= $k['id'] ?>" >
                                                                    <?php echo $k['category_name']; ?>
                                                                </option>
                                                        <?php
                                                    }
                                                }
                                                        ?>
                                    </select>
                    
                                </div>
                                <!-- <select class="form-select" aria-label="Default select example">
                                    <option selected>Open this select menu</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select> -->
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Base Unit</label><br>
                                    <select class="form-select" name="baseunit" id="baseunit">
                                        <?php
                                        if (!empty($base_unit)) {
                                            foreach ($base_unit as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>">
                                                    <?php echo $k['base_unit_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>



                            


                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Select Units</label>
                                    <input type="text" id="selectunit" name="selectunit">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Preferred Unit</label>
                                    <input type="text" id="preferredunit" name="preferredunit">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Code</label>
                                    <input type="number" id="itemcode" name="itemcode">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>GST Code</label>
                                    <input type="text" id="gstcode" name="gstcode">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>HSN/SAC Code Type</label>
                                    <input type="text" id="saccode" name="saccode">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Type For Base Kitchen</label>
                                    <select class="form-select" name="basekitchen" id="basekitchen">
                                        <?php
                                        if (!empty($base_kitchen_name)) {
                                            foreach ($base_kitchen_name as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>">
                                                    <?php echo $k['base_kitchen_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>


                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Section</label>
                                    <select class="form-select" name="section" id="section">
                                        <?php
                                        if (!empty($section)) {
                                            foreach ($section as $k) {
                                        ?>

                                                <option value="<?= $k['id'] ?>">
                                                    <?php echo $k['section_name']; ?>
                                                </option>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Item Type For Outlet</label>
                                    <input type="text" id="outlet" name="outlet">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Yield</label><br>
                                    <input type="text" id="yield" name="yield">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Non Stockable</label>
                                    <input type="text" id="stockable" name="stockable">
                                </div>
                            </div>

                            <div class="col-lg-3 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Alias Name</label>
                                    <input type="text" id="aliasname" name="aliasname">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <button type="submit" class="btn btn-primary">submit</button>
                                <a href="products" class="btn btn-warning">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>


</div>