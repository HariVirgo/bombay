<?php 
    $uri = service('uri');
?>

<aside class="main-sidebar sidebar-dark-primary elevation-4">
    

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo base_url(); ?>/public/assets1/img/bs_logo.png" style="width: 12.1rem;" alt="User Image">
        </div>
        <!-- <div class="info">
          <a href="#" class="d-block">Alexander Pierce</a>
        </div> -->
      </div>

     
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
         
          
           
              <li class="nav-item" <?php echo ($uri->getSegment(1)=="dashboard") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/dashboard' ?>" class="nav-link">
                  <i class="fas fa-home nav-icon"></i>
                  <p>Dashboard</p>
                </a>
              </li>
              <li class="nav-item"<?php echo ($uri->getSegment(1)=="semiprocessed") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/semiprocessed' ?>" class="nav-link">
                  <i class="fas fa-hamburger nav-icon"></i>
                  <p>Semi Processed</p>
                </a>
              </li>
              <li class="nav-item" <?php echo ($uri->getSegment(1)=="dispatch") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/dispatch' ?>" class="nav-link">
                  <i class="fas fa-box nav-icon"></i>
                  <p>Dispatch</p>
                </a>
              </li>
              <li class="nav-item" <?php echo ($uri->getSegment(1)=="barcode") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/barcode' ?>" class="nav-link">
                  <i class="fas fa-barcode nav-icon"></i>
                  <p>Barcode</p>
                </a>
              </li>
              <li class="nav-item"<?php echo ($uri->getSegment(1)=="category") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/category' ?>" class="nav-link">
                  <i class="fas fa-grip-vertical nav-icon"></i>
                  <p>Category</p>
                </a>
              </li>
              <li class="nav-item"<?php echo ($uri->getSegment(1)=="baseunit") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/baseunit' ?>" class="nav-link">
                  <i class="fas fa-memory nav-icon"></i>
                  <p>Base Unit</p>
                </a>
              </li>
              <li class="nav-item"<?php echo ($uri->getSegment(1)=="basekitchen") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/basekitchen' ?>" class="nav-link">
                <i class="fas fa-hotel nav-icon"></i>
                  <p>Base Kitchen</p>
                </a>
              </li>
              <li class="nav-item"<?php echo ($uri->getSegment(1)=="section") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/section' ?>" class="nav-link">
                <i class="fas fa-list nav-icon"></i>
                  <p>Section</p>
                </a>
              </li>
              <li class="nav-item" <?php echo ($uri->getSegment(1)=="products") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/products' ?>" class="nav-link">
                  <i class="fas fa-cart-plus nav-icon"></i>
                  <p>Products</p>
                </a>
              </li>
              <li class="nav-item"<?php echo ($uri->getSegment(1)=="location") ? 'class="active"' : ''; ?>>
                <a href="<?php echo base_url() . '/location' ?>" class="nav-link">
                  <i class="fas fa-map-marker-alt nav-icon"></i>
                  <p>Location</p>
                </a>
              </li>
             </ul>
         </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
