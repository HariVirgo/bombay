
        <footer class="main-footer">
            <strong>Copyright &copy; 2021-2023 <a href="#">
©Digital Makers Solution.</a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 1.1
            </div>
        </footer>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>/public/plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo base_url(); ?>/public/plugins/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo base_url(); ?>/public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- ChartJS -->
    <script src="<?php echo base_url(); ?>/public/plugins/chart.js/Chart.min.js"></script>
    <!-- Sparkline -->
    <!-- <script src="<?php echo base_url(); ?>/public/plugins/sparklines/sparkline.js"></script> -->
    <!-- JQVMap -->
    <!-- <script src="<?php echo base_url(); ?>/public/plugins/jqvmap/jquery.vmap.min.js"></script> -->
    <!-- <script src="<?php echo base_url(); ?>/public/plugins/jqvmap/maps/jquery.vmap.usa.js"></script> -->
    <!-- jQuery Knob Chart -->
    <script src="<?php echo base_url(); ?>/public/plugins/jquery-knob/jquery.knob.min.js"></script>
    <!-- daterangepicker -->
    <script src="<?php echo base_url(); ?>/public/plugins/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/public/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="<?php echo base_url(); ?>/public/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <!-- Summernote -->
    <script src="<?php echo base_url(); ?>/public/plugins/summernote/summernote-bs4.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo base_url(); ?>/public/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo base_url(); ?>/public/dist/js/adminlte.js"></script>
    <!-- AdminLTE for demo purposes -->
    <!-- <script src="<?php echo base_url(); ?>/public/dist/js/demo.js"></script> -->
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="<?php echo base_url(); ?>/public/dist/js/pages/dashboard.js"></script>

    <!-- <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script> -->
    <script src="<?php echo base_url(); ?>/public/assets/js/jquery.table2excel.min.js"></script>
<!--   Core JS Files   -->
<script src="<?php echo base_url(); ?>/public/assets1/js/core/popper.min.js"></script>
 <script src="<?php echo base_url(); ?>/public/assets1/js/core/bootstrap.min.js"></script>
 <script src="<?php echo base_url(); ?>/public/assets1/js/plugins/perfect-scrollbar.min.js"></script>
 <script src="<?php echo base_url(); ?>/public/assets1/js/plugins/smooth-scrollbar.min.js"></script>
 <script>
     var win = navigator.platform.indexOf('Win') > -1;
     if (win && document.querySelector('#sidenav-scrollbar')) {
         var options = {
             damping: '0.5'
         }
         Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
     }
 </script>
 

 <!-- Github buttons -->
 <!-- <script async defer src="https://buttons.github.io/buttons.js"></script> -->
 <script async defer src="<?php echo base_url(); ?>/public/assets/js/buttons.js"></script>
 <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
 <script src="<?php echo base_url(); ?>/public/assets1/js/material-dashboard.min.js?v=3.0.4"></script>
 <script src="<?php echo base_url(); ?>/public/assets/js/printthis.js"></script>
 <script src="<?php echo base_url(); ?>/public/assets/js/jquery-barcode.js"></script>
<!--  -->


</body>

</html>