<?php

namespace App\Controllers;

use App\Models\BasekitchenModel;
use App\Models\CategoryModel;
use App\Models\BaseunitModel;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Files\File;

class BaseunitController extends AdminController
{
    use ResponseTrait;

    public function __construct()
    {
        parent::__construct();
    }


    public function index()
    {

        $data = [];
        $base_unit_model = new BaseunitModel();
        $data['base_unit'] = $base_unit_model->getdata();
        return $this->render_template('pages/baseunit', $data);
    }

    public function baseunitform()
    {
        $session = session();
        $data = [

            'base_unit_name' => $this->request->getVar('base_unit'),
            'status' => $this->request->getVar('active'),
        ];
        $baseunit_model = new BaseunitModel();
        $baseunit =  $baseunit_model->baseunitcreate($data);
        if($baseunit){
            $session->setFlashdata('success', 'Base unit created');
            return redirect()->to('/baseunit');
        } else {
            $session->setFlashdata('error', 'Base unit not created');
            return redirect()->to('/baseunit');
        }
       
    }


    public function updatepost()
    {
        $session = session();
        $id = $this->request->getVar('id');
        $data = [
            'base_unit_name' => $this->request->getVar('base_unit'),
            'status' => $this->request->getVar('active')
        ];
        $base_unit_model = new BaseunitModel();
        $baseunit =  $base_unit_model->baseunitupdate($id, $data);
        if($baseunit){
            $session->setFlashdata('success', 'Successfully Update');
            return redirect()->to('/baseunit');
        } else {
            $session->setFlashdata('error', 'Update Faild');
            return redirect()->to('/baseunit');
        }
    }


    public function deleterow()
    {
        $session = session();
        $id = $this->request->getVar('id');
        $base_unit_model = new BaseunitModel();
        $baseunit =  $base_unit_model->deleterow($id);
        if($baseunit){
            $session->setFlashdata('success', 'Successfully Delete');
            return redirect()->to('/baseunit');
        } else {
            $session->setFlashdata('error', 'Delete Faild');
            return redirect()->to('/baseunit');
        }
    }
}
