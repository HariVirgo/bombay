<?php

namespace App\Controllers;
use App\Models\LocationModel;
use App\Models\ProductModel;
use CodeIgniter\API\ResponseTrait;



class DashboardController extends AdminController
{
    use ResponseTrait;

    public function __construct()
	{
		parent::__construct();
        // $this->load->Libraries('Zend');

	}

    public function index()
    {
        return $this->render_template('pages/dashboard', []);
        
    }

    public function category()
    {
        return $this->render_template('pages/category', []);
        
    }

    public function semiprocessed()
    {
        $data = [];
        $location_model = new LocationModel();
       $data['location'] = $location_model->getdata();
        return $this->render_template('pages/semiprocessed', $data);
       
    }

    public function dispatch()
    {
        $data = [];
        $location_model = new LocationModel();
       $data['location'] = $location_model->getdata();
        return $this->render_template('pages/dispatch', $data);
        
    }

    public function barcode()
    {
        return $this->render_template('pages/barcode', []);
        
    }

    
    public function getProductsByCode($p_code) {
        $reverse = strrev($p_code);
        $product_code = explode('000', $reverse);
          $api  = strrev($product_code[1]);
        $productModel = new ProductModel();
        
        // $products = $productModel->join('category', 'category.id = product.category_id', 'LEFT')->where('item_code', $product_codes[0])->orderBy('id', 'DESC')->findAll();
        $products = $productModel->getProductByItemCode($api);
        // print_r($products);
        

        if(count($products) > 0) {
            $response = [
                'status'   => 200,
                'error'    => null,
                'data'     => $products,
                'messages' => [
                    'success' => 'Products received'
                ],
            ];
        } else {
            
            $response['data'] = [];
            $response['messages'] = [
                'error' => 'Product not found'
            ];
            $response['status'] = 400;
        }

    //  print_r($response);
    //  die;

        return $this->respond($response);
    }

    public function getbarcode($p_code){

        $productModel = new ProductModel(); 
        $products = $productModel->getProductByItemCode($p_code);
        if(count($products) > 0) {
            $response = [
                'status'   => 200,
                'error'    => null,
                'data'     => $products,
                'messages' => [
                    'success' => 'Products received'
                ],
            ];
        } else {
            
            $response['data'] = [];
            $response['messages'] = [
                'error' => 'Product not found'
            ];
            $response['status'] = 400;
        }
        return $this->respond($response);
    }
   




   




     
}