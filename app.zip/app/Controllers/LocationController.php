<?php 
namespace App\Controllers;

use App\Models\BasekitchenModel;
use App\Models\CategoryModel;
use App\Models\BaseunitModel;
use App\Models\LocationModel;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Files\File;
use CodeIgniter\HTTP\Message;

class LocationController extends AdminController
{

    use ResponseTrait;

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
       $data=[];
       $location_model = new LocationModel();
       $data['location'] = $location_model->getdata();
        return $this->render_template('pages/location', $data);
    }


    public function locationcreate()
    {
        $session = session();

        $data = [
            'location_name' => $this->request->getVar('location'),
            'status' => $this->request->getVar('active'),
        ]; 
        $location_model = new LocationModel();   
        $location =  $location_model->locationcreate($data);
        if($location){
            $session->setFlashdata('success', 'Base unit created');
            return redirect()->to('/location');
        } else {
            $session->setFlashdata('error', 'Base unit not created');
            return redirect()->to('/location');
        }
    }

    public function updatelocation(){
        $session = session();
        $id = $this->request->getVar('id');
        $data = [
            'location_name' => $this->request->getVar('location'),
            'status' => $this->request->getVar('active')
        ];
        $location_model = new LocationModel();
        $location =  $location_model->locationupdate($id, $data);
        if($location){
            $session->setFlashdata('success', 'Successfully Update');
            return redirect()->to('/location');
        } else {
            $session->setFlashdata('error', 'Update Faild');
            return redirect()->to('/location');
        }
    }

    
    public function deletelocation()
    {
        $session = session();
        $id = $this->request->getVar('id');
        $location_model = new LocationModel();
        $location =  $location_model->deleterow($id);
        if($location){
            $session->setFlashdata('success', 'Successfully Delete');
            return redirect()->to('/location');
        } else {
            $session->setFlashdata('error', 'Delete Faild');
            return redirect()->to('/location');
        }
    }


}