<?php

namespace App\Controllers;

class AuthController extends AdminController
{

    public function __construct()
	{
		parent::__construct();

		
	}

    public function index()
    {
        return $this->render_template_auth('login', []);
        // return view('login');
    }
    
}