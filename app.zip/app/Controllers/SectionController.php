<?php

namespace App\Controllers;

use App\Models\SectionModel;
use App\Models\BasekitchenModel;
use App\Models\CategoryModel;
use App\Models\BaseunitModel;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Files\File;

class SectionController extends AdminController
{
    use ResponseTrait;

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
       
        $data = [];
        $section_model = new SectionModel();
        $data['section'] = $section_model->getdata();
        return $this->render_template('pages/section', $data);
    }

    public function sectionform()
    {
        $session = session();
        $data = [

            'section_name' => $this->request->getVar('section'),
            'status' => $this->request->getVar('active'),
        ];
        $section_model = new SectionModel();
        $section =  $section_model->sectioncreate($data);

        if($section){
            $session->setFlashdata('success', 'Section created');
            return redirect()->to('/section');
        } else {
            $session->setFlashdata('error', 'Section not created');
            return redirect()->to('/section');
        }
    }


    public function sectionupdate()
    {
        // print_r('hari');
        // die;
        $session = session();
        $id = $this->request->getVar('id');
        $data = [
            'section_name' => $this->request->getVar('section'),
            'status' => $this->request->getVar('active')
        ];
        $section_model = new SectionModel();
        $section =  $section_model->sectionupdate($id, $data);
        if($section){
            $session->setFlashdata('success', 'Successfully Update');
            return redirect()->to('/section');
        } else {
            $session->setFlashdata('error', 'Update Faild');
            return redirect()->to('/section');
        }
       
    }


    public function sectiondelete()
    {
        $session = session();
        $id = $this->request->getVar('id');
        $section_model = new SectionModel();
        $section =  $section_model->deleterow($id);
        
        if($section){
            $session->setFlashdata('success', 'Successfully Delete');
            return redirect()->to('/section');
        } else {
            $session->setFlashdata('error', 'Delete Faild');
            return redirect()->to('/section');
        }
    }

    public function getSectionbycode($s_code){

        $section_model = new SectionModel();
        $section =  $section_model->getsectionName($s_code);
      return json_encode($section);
    }




}