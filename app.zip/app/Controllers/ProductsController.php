<?php

namespace App\Controllers;

use App\Models\BasekitchenModel;
use App\Models\SectionModel;
use App\Models\CategoryModel;
use App\Models\BaseunitModel;
use App\Models\ProductModel;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Files\File;


class ProductsController extends AdminController
{
    use ResponseTrait;

    public function __construct()
    {
        // $session = session();
        parent::__construct();
    }



    public function products()
    {
        $product_model = new ProductModel();
        // $data['products'] = $product_model->getProducts();
        $data['productstable'] = $product_model->getdata();
        return $this->render_template('pages/products', $data);
    }

    public function productsform()
    {
        $data=[];
        $category_model = new CategoryModel();
        $data['category']=$category_model->getdata();

        $base_unit_model = new BaseunitModel();
        $data['base_unit'] =  $base_unit_model->getdata();

        $base_kitchen_model = new BasekitchenModel();
        $data['base_kitchen_name'] = $base_kitchen_model->getdata();


        $section_model = new SectionModel();
        $data['section'] = $section_model->getdata();

        return $this->render_template('pages/productsform', $data);
    }

    public function create()
    {
        $session = session();

       $data=[
       'item_name' =>$this->request->getVar('iname'),
      'category_id' => $this->request->getVar('category'),
      'base_unit_id' => $this->request->getVar('baseunit'),
      'select_unit' => $this->request->getVar('selectunit'),
      'preferred_unit' => $this->request->getVar('preferredunit'),
      'item_code' => $this->request->getVar('itemcode'),
      'gst_code' => $this->request->getVar('gstcode'),
      'sac_code' => $this->request->getVar('saccode'),
      'base_kitchen_id' => $this->request->getVar('basekitchen'),
      'section_id' => $this->request->getVar('section'),
      'type_outlet' => $this->request->getVar('outlet'),
      'yield' => $this->request->getVar('yield'),
      'non_stockable' => $this->request->getVar('stockable'),
      'aliase_name' => $this->request->getVar('aliasname'),
       ];
            // print_r($data);
            // die;
       $products_model = new ProductModel();
       $products = $products_model->createproducts($data);
       
        if($products){
            $session->setFlashdata('success', 'Product created');
            return redirect()->to('/products');
        } else {
            $session->setFlashdata('error', 'Product not created');
            return redirect()->to('/products');
        }

    }

    public function upload()
    {
        // print_r('coming');
        // die;
        $data = array();
        $file = $this->request->getFile('file');
        if (!$file) {
            $data['status'] = 0;
            $data['message'] = 'No File Selected';
            redirect('products', $data);
        }
        // echo "<pre>";
        if (!$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file_move = $file->move('public/csvfile', $newName);
            $file = fopen("public/csvfile/" . $newName, "r");

            // print_r($file);
            // die;
            $i = 0;
            $numberOfFields = 13;
            $csvArr = array();

            $category_model = new CategoryModel();
            $base_unit_model = new BaseunitModel();
            $base_kitchen_model = new BasekitchenModel();

            while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                $num = count($filedata);

                if ($i > 0 && $num == $numberOfFields) {
                    $csvArr[$i]['item_name'] = $filedata[0];
                    $category_name = $filedata[1];
                    $category_id = $category_model->insertCategoryIfNotExist($category_name);
                    $csvArr[$i]['category_id'] =  $category_id;
                    $base_unit_name = $filedata[2];
                    $base_unit_id = $base_unit_model->insertBaseunitIfNotExist($base_unit_name);
                    $csvArr[$i]['base_unit_id'] = $base_unit_id;
                    $csvArr[$i]['select_unit'] = $filedata[3];
                    $csvArr[$i]['preferred_unit'] = $filedata[4];
                    $csvArr[$i]['item_code'] = $filedata[5];
                    $csvArr[$i]['gst_code'] = $filedata[6];
                    $csvArr[$i]['sac_code'] = $filedata[7];
                    $base_kitchen_name = $filedata[8];
                    $base_kitchen_id = $base_kitchen_model->insertBasekitchenIfNotExist($base_kitchen_name);
                    $csvArr[$i]['base_kitchen_id'] = $base_kitchen_id;
                    $csvArr[$i]['type_outlet'] = $filedata[9];
                    $csvArr[$i]['yield'] = $filedata[10];
                    $csvArr[$i]['non_stockable'] = $filedata[11];
                    $csvArr[$i]['aliase_name'] = $filedata[12];
                }
                $i++;
            }
            fclose($file);

            $count = 0;
            $product_model = new ProductModel();
            foreach ($csvArr as $productdata) {
                $findRecord = $product_model->where('item_name', $productdata['item_name'])->countAllResults();
                //   print_r($findRecord);
                // die;   
                if ($findRecord == 0) {
                    if ($product_model->insertproduct($productdata)) {
                        $count++;
                    }
                } 
                // print_r($productdata);
                // die;

            }
            $message = 'success';
        }
        $data = ['errors' => 'The file has already been moved.'];
        // redirect('products'[]);
        json_encode($message);
    }

    public function productsdelete(){
        $session = session();
        $id = $this->request->getVar('id');
        $products_model = new ProductModel();
        $products =  $products_model ->deleterow($id);
        
        if($products){
            $session->setFlashdata('success', 'Successfully Delete');
            return redirect()->to('/products');
        } else {
            $session->setFlashdata('error', 'Not a Delete');
            return redirect()->to('/products');
        }
    }

    public function productEditById($id){
        
        $data=[];
        $category_model = new CategoryModel();
        $data['category']=$category_model->getdata();

        $base_unit_model = new BaseunitModel();
        $data['base_unit'] =  $base_unit_model->getdata();

        $base_kitchen_model = new BasekitchenModel();
        $data['base_kitchen_name'] = $base_kitchen_model->getdata();

        $section_model = new SectionModel();
        $data['section'] = $section_model->getdata();
 
        $products_model = new ProductModel();
        $products_data = $products_model->editdata($id);
        $data['products'] = $products_data;
        

        return $this->render_template('pages/productseditform', $data);  
    }

   public function updateproducts(){
    $session = session();
    $id=$this->request->getVar('id');
    $data=[
        'item_name' =>$this->request->getVar('iname'),
       'category_id' => $this->request->getVar('category'),
       'base_unit_id' => $this->request->getVar('baseunit'),
       'select_unit' => $this->request->getVar('selectunit'),
       'preferred_unit' => $this->request->getVar('preferredunit'),
       'item_code' => $this->request->getVar('itemcode'),
       'gst_code' => $this->request->getVar('gstcode'),
       'sac_code' => $this->request->getVar('saccode'),
       'base_kitchen_id' => $this->request->getVar('basekitchen'),
       'section_id' => $this->request->getVar('section'),
       'type_outlet' => $this->request->getVar('outlet'),
       'yield' => $this->request->getVar('yield'),
       'non_stockable' => $this->request->getVar('stockable'),
       'aliase_name' => $this->request->getVar('aliasname'),
        ];
        $products_model = new ProductModel();
        $products =  $products_model->productupdate($id,$data);
    // print_r($id);
    // die;
    if($products){
        $session->setFlashdata('success', 'Successfully Update');
        return redirect()->to('/products');
    } else {
        $session->setFlashdata('error', 'Update Faild');
        return redirect()->to('/products');
    }
   }
}
