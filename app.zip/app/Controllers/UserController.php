<?php

namespace App\Controllers;
use App\Models\UserModel;


class UserController extends AdminController
{

    public function __construct()
	{
		parent::__construct();
        helper(['form']);
	}

    // show users list
    public function index(){
        $userModel = new UserModel();
        $data['users'] = $userModel->orderBy('id', 'DESC')->findAll();
        return view('pages/users', $data);
    }

    public function loginAuth()
    {
       
        
        $session = session();
        $userModel = new UserModel();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        // echo $email;
        // print_r('coming');
        // die;

        $data = $userModel->where('email', $email)->first();
        echo base_url();

        if($data){
            $pass = $data['password'];
            $authenticatePassword = password_verify($password, $pass);
            if($authenticatePassword){
                $ses_data = [
                    'id' => $data['id'],
                    // 'name' => $data['name'],
                    'email' => $data['email'],
                    'isLoggedIn' => TRUE
                ];
                $session->set($ses_data);
                return redirect()->to('/dashboard');
            
            }else{
                $session->setFlashdata('msg', 'Password is incorrect.');
                return redirect()->to('/auth/login');
                // redirect(base_url('c_home'), 'refresh');

            }
        }else{
            $session->setFlashdata('msg', 'Email does not exist.');
            return redirect()->to('/auth/login');
        }
    }

}





