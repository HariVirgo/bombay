<?php

namespace App\Controllers;

use App\Models\BasekitchenModel;
use App\Models\CategoryModel;
use App\Models\BaseunitModel;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Files\File;

class BasekitchenController extends AdminController
{
    use ResponseTrait;

    public function __construct()
    {
        parent::__construct();
    }


    public function index()
    {

        $data = [];
        $base_kitchen_model = new BasekitchenModel();
        $data['base_kitchen'] = $base_kitchen_model->getdata();
        return $this->render_template('pages/basekitchen', $data);
    }

    public function basekitchenform()
    {
        $session = session();
        $data = [

            'base_kitchen_name' => $this->request->getVar('base_kitchen'),
            'status' => $this->request->getVar('active'),
        ];
        $base_kitchen_model = new BasekitchenModel();
        $base_kitchen =  $base_kitchen_model->basekitchencreate($data);

        if($base_kitchen){
            $session->setFlashdata('success', 'Base kitchen created');
            return redirect()->to('/basekitchen');
        } else {
            $session->setFlashdata('error', 'Base kitchen not created');
            return redirect()->to('/basekitchen');
        }
    }

    // public function edit($id){

    //     $base_kitchen_model = new BasekitchenModel();
    //     $data['edit'] = $this->$base_kitchen_model->getWhere(['id'=>$id])->getrow();
    //     return $this->render_template('pages/basekitchen', $data);

    // }

    public function updatepost()
    {
        $session = session();
        $id = $this->request->getVar('id');
        $data = [
            'base_kitchen_name' => $this->request->getVar('base_kitchen'),
            'status' => $this->request->getVar('active')
        ];
        $base_kitchen_model = new BasekitchenModel();
        $base_kitchen =  $base_kitchen_model->basekitchenupdate($id, $data);
        if($base_kitchen){
            $session->setFlashdata('success', 'Successfully Update');
            return redirect()->to('/basekitchen');
        } else {
            $session->setFlashdata('error', 'Update Faild');
            return redirect()->to('/basekitchen');
        }
       
    }


    public function basekitchendelete()
    {
        $session = session();
        $id = $this->request->getVar('id');
        $base_kitchen_model = new BasekitchenModel();
        $base_kitchen =  $base_kitchen_model->deleterow($id);
        
        if($base_kitchen){
            $session->setFlashdata('success', 'Successfully Delete');
            return redirect()->to('/basekitchen');
        } else {
            $session->setFlashdata('error', 'Delete Faild');
            return redirect()->to('/basekitchen');
        }
    }

    //    public function show(){
    //     $data = [];
    //     $base_kitchen_model = new BasekitchenModel();
    //     $data['base_kitchen']= $base_kitchen_model->getdata();

    //     return view('pages/basekitchen', $data);
    //     // print_r($data);
    //     // die;
    //     //   echo json_encode($data);
    //    }

}
