<?php

namespace App\Controllers;

use App\Models\BasekitchenModel;
use App\Models\CategoryModel;
use App\Models\BaseunitModel;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Files\File;
use CodeIgniter\HTTP\Message;

class CategoryController extends AdminController
{
    use ResponseTrait;

    public function __construct()
    {
        parent::__construct();
    }


    public function index()
    {
        $data=[];
        $category_model = new CategoryModel();
        $data['category']= $category_model->getdata();
        return $this->render_template('pages/category', $data);
    }

    public function categoryform()
    {
        $session = session();
        $data = [

            'category_name' => $this->request->getVar('name'),
            'status' => $this->request->getVar('active'),
        ];
        //  print_r($data);
        //  die;
        $category_model = new CategoryModel();
        $category =  $category_model->createcategory($data);

        if($category){
            $session->setFlashdata('success', 'Category created');
            return redirect()->to('/category');
        } else {
            $session->setFlashdata('error', 'Category not created');
            return redirect()->to('/category');
        }
    }


    public function updatecategory(){
        $session = session();
        $id=$this->request->getVar('id');
        $data=[
            'category_name' => $this->request->getVar('category'),
           'status' => $this->request->getVar('active') 
        ];
        // print_r($data);
        // die;
        $category_model = new CategoryModel();
        $category =  $category_model ->categoryupdate($id,$data);
        
        if($category){
            $session->setFlashdata('success', 'Successfully Update');
            return redirect()->to('/category');
        } else {
            $session->setFlashdata('error', 'Update Faild');
            return redirect()->to('/category');
        }
    }


    public function categorydelete(){
        $session = session();
        $id = $this->request->getVar('id');
        $category_model = new CategoryModel();
        $category =  $category_model ->deleterow($id);
        
        if($category){
            $session->setFlashdata('success', 'Successfully Delete');
            return redirect()->to('/category');
        } else {
            $session->setFlashdata('error', 'Delete Faild');
            return redirect()->to('/category');
        }
    }
}
