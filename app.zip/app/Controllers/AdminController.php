<?php 

 namespace App\Controllers;

class MY_Controller extends BaseController
{
	public function __construct()
	{
		
	}
}

class AdminController extends MY_Controller 
{
	var $permission = array();

	public function __construct() 
	{
		parent::__construct();

		// $group_data = array();
		// if(empty($this->session->userdata('logged_in'))) {
		// 	$session_data = array('logged_in' => FALSE);
		// 	$this->session->set_userdata($session_data);
		// }
		// else {
		// 	$user_id = $this->session->userdata('id');
		// 	$this->load->model('model_groups');
		// 	$group_data = $this->model_groups->getUserGroupByUserId($user_id);
			
		// 	$this->data['user_permission'] = unserialize($group_data['permission']);
		// 	$this->permission = unserialize($group_data['permission']);
		// }
	}

	public function logged_in()
	{
		$session_data = $this->session->userdata();
		if($session_data['logged_in'] == TRUE) {
			redirect('dashboard', 'refresh');
		}
	}

	public function not_logged_in()
	{
		$session_data = $this->session->userdata();
		if($session_data['logged_in'] == FALSE) {
			redirect('auth/login', 'refresh');
		}
	}

	public function render_template($page = null, $data = array())
	{
       
		// echo $page;
		// print_r($data);

		return view('templates/header').view('templates/sidebar').view($page, $data).view('templates/footer');


	}

    public function render_template_auth($page = null, $data = array())
	{
		return view($page, $data);
	}

	

	
	
}